"""Static HIG regression checks for the GTK frontend (runs without GI/GTK installed)."""
import ast
import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UI_PATH = ROOT / "padshift_gtk.py"
UI_SOURCE = UI_PATH.read_text(encoding="utf-8")
INSTALL_SOURCE = (ROOT / "install.sh").read_text(encoding="utf-8")
README_SOURCE = (ROOT / "README.md").read_text(encoding="utf-8")


class GtkUiStructureTests(unittest.TestCase):
    def test_frontend_parses_and_has_no_duplicate_methods(self):
        tree = ast.parse(UI_SOURCE)
        app = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "PadShiftGtkApp")
        names = [node.name for node in app.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
        duplicates = sorted(name for name in set(names) if names.count(name) > 1)
        self.assertEqual(duplicates, [], f"Duplicate methods shadow one another: {duplicates}")

    def test_uses_native_libadwaita_shell_and_patterns(self):
        for token in (
            "Adw.ApplicationWindow", "Adw.NavigationSplitView", "Adw.NavigationPage",
            "Adw.ToolbarView", "Adw.HeaderBar", "Adw.PreferencesDialog",
            "Adw.PreferencesGroup", "Adw.ActionRow", "Adw.SwitchRow", "Adw.AlertDialog",
        ):
            with self.subTest(token=token):
                self.assertIn(token, UI_SOURCE)

    def test_uses_responsive_breakpoints_and_native_collapsed_navigation(self):
        self.assertIn('"max-width: 850sp"', UI_SOURCE)
        self.assertIn('"max-width: 1180sp"', UI_SOURCE)
        self.assertIn("AdwHeaderBar integrates with AdwNavigationSplitView", UI_SOURCE)
        self.assertNotIn("self.back_button", UI_SOURCE)

    def test_no_custom_css_theme_is_injected(self):
        self.assertNotIn("Gtk.CssProvider", UI_SOURCE)
        self.assertNotIn("load_from_data", UI_SOURCE)
        self.assertNotIn("def _install_css", UI_SOURCE)

    def test_custom_drawing_has_keyboard_alternative(self):
        self.assertIn("Game-side control", UI_SOURCE)
        self.assertIn("self.learn_button", UI_SOURCE)
        self.assertIn("set_tooltip_text(\"Controller illustration.", UI_SOURCE)
        self.assertIn("update_property_value", UI_SOURCE)

    def test_shortcut_dialog_uses_libadwaita_when_available(self):
        self.assertIn('getattr(Adw, "ShortcutLabel", None)', UI_SOURCE)
        self.assertIn("Gtk.ShortcutLabel", UI_SOURCE)  # fallback for earlier GTK 4/libadwaita

    def test_app_icons_are_valid_hicolor_svg_assets(self):
        app_icon = ROOT / "icons/scalable/apps/io.github.privacyfreak84.PadShift.svg"
        symbolic_icon = ROOT / "icons/symbolic/apps/io.github.privacyfreak84.PadShift-symbolic.svg"
        for icon_path in (app_icon, symbolic_icon):
            with self.subTest(icon=icon_path.name):
                root = ET.parse(icon_path).getroot()
                self.assertEqual(root.tag, "{http://www.w3.org/2000/svg}svg")
                self.assertEqual(root.attrib.get("viewBox"), "0 0 128 128" if "scalable/apps" in str(icon_path) else "0 0 16 16")
        self.assertIn("fill=\"currentColor\"", symbolic_icon.read_text(encoding="utf-8"))

    def test_installer_uses_unique_app_identity_and_symbolic_icon_location(self):
        self.assertIn('APP_ID="io.github.privacyfreak84.PadShift"', INSTALL_SOURCE)
        self.assertIn('Icon=$APP_ID', INSTALL_SOURCE)
        self.assertIn('icons/symbolic/apps/$APP_ID-symbolic.svg', INSTALL_SOURCE)
        self.assertIn('Categories=Game;Utility;', INSTALL_SOURCE)
        self.assertNotIn('Icon=input-gaming', INSTALL_SOURCE)


    def test_expander_row_does_not_call_action_row_only_api(self):
        # Adw.ExpanderRow exposes add_suffix()/add_row(), but has no
        # set_activatable_widget() method (that method belongs to Adw.ActionRow).
        self.assertNotIn("expander.set_activatable_widget(", UI_SOURCE)
        tree = ast.parse(UI_SOURCE)
        calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Attribute)
                 and node.func.attr == "set_activatable_widget"
                 and isinstance(node.func.value, ast.Name)
                 and node.func.value.id == "expander"]
        self.assertEqual(calls, [])

    def test_page_navigation_uses_visible_sliding_transition(self):
        self.assertIn("Gtk.StackTransitionType.SLIDE_LEFT_RIGHT", UI_SOURCE)
        self.assertIn("self.stack.set_transition_duration(280)", UI_SOURCE)

    def test_dialogs_have_a_real_opacity_animation(self):
        self.assertIn("Adw.TimedAnimation", UI_SOURCE)
        self.assertIn("PropertyAnimationTarget", UI_SOURCE)
        self.assertIn("animation.play()", UI_SOURCE)
        self.assertIn("GTK settings", UI_SOURCE)

    def test_remapping_worker_is_not_disowned_by_ui_refresh_errors(self):
        tree = ast.parse(UI_SOURCE)
        app = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "PadShiftGtkApp")
        method = next(node for node in app.body if isinstance(node, ast.FunctionDef) and node.name == "start_worker")
        source = ast.get_source_segment(UI_SOURCE, method)
        self.assertLess(source.index("process = subprocess.Popen"), source.index("self.worker = process"))
        self.assertIn("Remapper started, but refreshing the interface failed", source)
        self.assertIn("return True", source)

    def test_docs_disclose_hig_and_accessibility_validation_scope(self):
        self.assertIn("official GNOME Human Interface Guidelines", README_SOURCE)
        self.assertIn("not been launched or checked with Orca/GTK Inspector", README_SOURCE)
        self.assertTrue((ROOT / "DESIGN-HIG.md").exists())


if __name__ == "__main__":
    unittest.main()
