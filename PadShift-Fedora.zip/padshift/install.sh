#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if ! command -v dnf >/dev/null 2>&1; then
  echo "This installer expects Fedora/dnf. Install python3-evdev and python3-tkinter with your distribution's package manager." >&2
  exit 1
fi

# System packages and one narrowly scoped udev rule are installed once. PadShift itself
# then runs as the logged-in user, with no pkexec/password dialog when it starts/reconnects.
sudo dnf install -y python3-evdev python3-tkinter
RULE_TMP="$(mktemp)"
MODULE_TMP="$(mktemp)"
trap 'rm -f "$RULE_TMP" "$MODULE_TMP"' EXIT
cat > "$RULE_TMP" <<'RULE'
# Give the active local desktop session access to the virtual gamepad device.
# TAG+=uaccess grants a seat ACL, rather than adding the user to the broad input group.
SUBSYSTEM=="misc", KERNEL=="uinput", OPTIONS+="static_node=uinput", TAG+="uaccess"
RULE
printf 'uinput\n' > "$MODULE_TMP"
sudo install -D -m 0644 "$RULE_TMP" /etc/udev/rules.d/70-padshift-uinput.rules
sudo install -D -m 0644 "$MODULE_TMP" /etc/modules-load.d/padshift.conf
sudo modprobe uinput
if command -v udevadm >/dev/null 2>&1; then
  sudo udevadm control --reload-rules
  sudo udevadm trigger --action=change --subsystem-match=misc --sysname-match=uinput || true
fi

APP_DIR="$HOME/.local/share/padshift"
BIN_DIR="$HOME/.local/bin"
APPS_DIR="$HOME/.local/share/applications"
mkdir -p "$APP_DIR" "$BIN_DIR" "$APPS_DIR"
install -m 0644 "$HERE/padshift.py" "$APP_DIR/padshift.py"
cat > "$BIN_DIR/padshift" <<'LAUNCH'
#!/usr/bin/env bash
exec /usr/bin/python3 "$HOME/.local/share/padshift/padshift.py" "$@"
LAUNCH
chmod 0755 "$BIN_DIR/padshift"
cat > "$APPS_DIR/padshift.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=PadShift Controller Remapper
Comment=Remap a gamepad into a virtual controller
Exec=$BIN_DIR/padshift
Icon=input-gaming
Terminal=false
Categories=Game;Utility;
DESKTOP
chmod 0644 "$APPS_DIR/padshift.desktop"

echo
echo "PadShift installed. It will start the saved profile automatically and follow the selected controller through disconnects."
echo "Normal launching/reconnecting no longer uses pkexec or requests a password."
echo "If /dev/uinput was already present, the udev rule was reloaded; if PadShift reports Permission denied, log out and back in once, then relaunch."
echo "Launch from the application menu or run: $BIN_DIR/padshift"
