# PadShift 0.8.2

**A destination-first Linux controller remapper for Fedora KDE.** PadShift reads your physical gamepad through `evdev` and publishes a remapped virtual Xbox 360-compatible controller through `uinput`. Native Linux games, Steam, Wine/Proton, and games launched through Bottles can use the virtual controller.

## The new seamless mode

PadShift now remembers the selected profile and physical controller. With **Keep remapping active automatically** enabled (the default):

- The selected profile starts automatically when you open PadShift.
- The virtual gamepad stays alive if the physical Xbox controller disconnects.
- PadShift searches for the same physical controller and reconnects when it returns, even if Linux assigns it a different `/dev/input/eventN` path.
- The selected profile is applied automatically after reconnect. No Run & monitor tab visits or second start click are needed.
- Switching profiles while remapping is active changes the running remapper immediately.
- Normal application launches and reconnections do not invoke `pkexec` and do not ask for a password.

Use the **Keep remapping active automatically** checkbox to disable automatic activation. Clicking **Stop remapping** also turns the checkbox off for the current preference, so PadShift won't immediately start itself again.

### One-time permission setup

The installer sets up a small udev rule for `/dev/uinput` using the active desktop session's `uaccess` ACL. It does **not** add your account to the broad `input` group. The remapper then runs as your normal user, instead of running a user-writable Python script as root.

Run the installer once after extracting the download:

```bash
./install.sh
```

It may ask for your password to install packages and the system udev rule. That is setup-time authorization, not something PadShift should ask for on launch or reconnect. If the app reports `Permission denied` for `/dev/uinput` after installing, log out of KDE and back in once so the active-session device ACL is refreshed, then relaunch PadShift.

## Learn a layout

The **Visual remapper** is the main view. It displays an Xbox-style controller representing what the game should receive.

1. Click the output button or control in the drawing. For a stick, click one of the directional arrows around that stick.
2. PadShift starts listening. Press the physical button or move the stick/trigger you want to bind.
3. The app confirms the exact mapping, updates the current-mappings list, and saves button/axis captures automatically.

Examples:

- Click virtual **X**, then press physical **A**: physical A sends X.
- Click **left stick ↑**, then pull the physical **right stick down**: PadShift maps the physical right-stick Y axis to the virtual left-stick Y axis and automatically enables inversion.
- Click a D-pad direction, then press the physical direction you want to use.
- Click LT or RT, then squeeze the physical trigger.
- Click a face button such as A, then push the physical D-pad or squeeze a trigger. Axis-based D-pad and trigger movement can now activate digital game buttons too.

Stick direction learning routes the entire analogue axis, including its opposite direction. The same view exposes axis destination, inversion, deadzone, response curve, and stick X/Y swap/reset controls. Use **Save changes** after manual tuning changes. Create named profiles for different layouts with **Save as…**.

The **Advanced: Buttons** and **Advanced: Axes** tabs remain available for list-based edits.

## Features

- Destination-first visual button learning.
- Destination-first stick, trigger, and D-pad axis learning with automatic inversion.
- Axis-to-button learning for D-pads, analog triggers, and stick directions, with a 55% default activation threshold.
- Digital D-pad button events are emitted alongside hat-axis events; analog LT/RT events also emit digital trigger-button events for games that expect them.
- LT/RT remapping works in both directions: a button (LB, A, a stick click, ...) mapped to LT or RT presses the *analog* trigger fully, alongside the real trigger (the strongest value wins), and a physical trigger mapped to a button stops acting as an analog trigger.
- Live input capture feedback, diagnostics, and controller activity monitor.
- Profiles saved in `~/.config/padshift/profiles/`; the active profile and selected physical controller are remembered in `~/.config/padshift/settings.json`.
- One long-lived virtual gamepad across physical controller disconnects.
- Automatic reconnection using controller vendor/product IDs and available device identity; event node numbering does not have to stay the same.
- Live profile switching without stopping the virtual controller.
- Games & Bottles diagnostics and opt-in Flatpak Bottles input access.

PadShift does not currently forward controller rumble or map controller inputs to keyboard keys. Button-to-button, axis-to-axis, and axis-direction-to-button mappings are supported. Digital D-pad/trigger button events are emitted alongside their axis equivalents for compatibility with games that consume either representation.

## First run

1. Connect the Xbox controller and launch PadShift.
2. Select it in the **Physical controller** list if it wasn't selected automatically.
3. Create or choose your profile and map controls.
4. Leave **Keep remapping active automatically** checked. The virtual controller starts without visiting another tab.
5. Launch your game. If the game was already open before the virtual controller appeared, restart the game so it rescans controllers.

To stop using PadShift, click **Stop remapping**. To use the physical controller directly, close PadShift or leave automatic activation disabled.

## Bottles and sandboxed games

PadShift creates the virtual controller on the host Linux input layer. For Flatpak Bottles, if the game cannot see it, open **Games & Bottles** and choose **Enable Flatpak input access…**, then fully quit and reopen Bottles. This applies the user override:

```bash
flatpak override --user --device=input com.usebottles.bottles
```

The override grants Bottles access to host input devices under `/dev/input`. Bottles' per-bottle **Dedicated sandbox** is a separate layer; disable it for that bottle if the controller remains invisible. Native RPM/AppImage Bottles does not need the Flatpak-specific override.

## Troubleshooting

- **Permission denied opening `/dev/uinput`:** rerun `./install.sh`, then log out of KDE and back in once. PadShift runs as your normal user and does not request password authentication during activation.
- **Reconnect didn't happen:** wait a second or two. The helper scans for the selected controller periodically. Check the activity log for the exact controller identity/status. If you replaced the controller with a different one, select the new device once while remapping is stopped.
- **Wrong controller selected:** stop remapping, use **Scan**, choose the correct physical device, then leave automatic activation enabled. PadShift remembers that selection.
- **Mapping controls:** stop remapping before learning new buttons. While active, PadShift grabs the physical controller so other apps see only the remapped virtual pad.
- **Updated PadShift but behaviour didn't change:** `./install.sh` copies the app to `~/.local/share/padshift/`. Re-run it (or copy `padshift.py` there), fully quit PadShift, and check the version in the footer/title bar.
- **LT/RT do nothing in a game:** open PadShift’s activity monitor and squeeze each trigger. For an analog trigger, the monitor should report movement and an output percentage; for a digital-only trigger, a BTN_TL2 / BTN_TR2 press should also produce a full analog axis press. After updating trigger behavior, fully close and relaunch the game so it enumerates the virtual controller again. If only one trigger is affected, re-learn that destination by clicking LT or RT and squeezing the physical trigger.
- **Flatpak Bottles can't see it:** use the Games & Bottles tab to enable input access, restart Bottles, and check Dedicated sandbox.

## Uninstall

```bash
./uninstall.sh
```

Uninstall removes the app and the udev rule/module-load configuration but leaves profiles in `~/.config/padshift/` intact.

## Developer checks

Run the included tests with:

```bash
python3 -m unittest discover -s tests -v
```

Tests cover LT/RT remapping with a realistic profile (button→trigger, trigger→button, bumper/trigger swap, analog+digital pads), axis transforms, analog-axis-to-button learning for D-pad and trigger events, digital-to-analog trigger fallback and release, alternate trigger-axis routing, digital D-pad/trigger output compatibility, destination-first mapping, input learning, and stable controller identity matching across reconnects. Automated tests do not replace a real-hardware test; PadShift has not been verified against every USB/Bluetooth Xbox One firmware variant.
